Bienvenue dans mon répertoire bridge

gambling.jpg

Photo obtenue sur www.pexels.com, totalement libre

VERSION BETA lancée

Le programme s'appelle bridgeutil.py

Sa fonctionnalité consiste à 

Distribuer des donnes aléatoirement filtrées selon des critères d'enchères

Sauvegarder ces donnes pour transmission à un partenaire sous forme de fichier .pak

Enchérir ces donnes avec son partenaire, chacun ne voyant que sa main

Afficher les deux mains puis les quatre mains à l'issue des enchères pour discussion

Le mode d'emploi sera disponible prochainement

Pour fonctionner, il a besoin 

-> de ses 5 fichiers lib
bridgelib.py
tklib.py
IOlib.py
donnelib.py
sequencelib.py

-> d'un répertoire data contenant au moins 3 fichiers :

une image valide : gambling.jpg

un fichier filtres.fil valide

un fichier sequence.fil valide

On y stocke les packs de donnes .pak


Contact : hquatreville@free.fr




