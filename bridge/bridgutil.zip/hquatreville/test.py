#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 16 17:57:57 2018

@author: hubert
"""


def test(n=0):
    x = 3
