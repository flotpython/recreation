-> Lancer la version Beta afin de la tester

-> Ecrire un mode d'emploi

Moins urgent :

-> Nettoyer le code

-> Mettre un peu de couleur



